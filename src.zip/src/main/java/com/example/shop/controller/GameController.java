package com.example.shop.controller;

import com.example.shop.models.User;
import com.example.shop.models.UserProgress;
import com.example.shop.services.UserProgressService;
import com.example.shop.services.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@Slf4j
public class GameController {

    private final UserService userService;
    private final UserProgressService progressService;

    private User currentUser(Principal principal, Authentication auth) {
        if (auth instanceof OAuth2AuthenticationToken t)
            return userService.getUserByEmail(t.getPrincipal().getAttribute("email"));
        if (principal != null)
            return userService.findUserByPrincipal(principal.getName());
        return null;
    }

    /** Games hub */
    @GetMapping("/games")
    public String gamesHub(Model model, Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user == null) return "redirect:/login";
        model.addAttribute("progress", progressService.getOrCreate(user.getId()));
        return "games_hub";
    }

    /** Physical minigame page */
    @GetMapping("/game/muscles")
    public String musclesGame(Model model, Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user != null) {
            model.addAttribute("progress", progressService.getOrCreate(user.getId()));
        }
        return "minigame_physical";
    }

    /** Trainer RPG game page */
    @GetMapping("/game/trainer")
    public String trainerGame(Model model, Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user != null) {
            model.addAttribute("progress", progressService.getOrCreate(user.getId()));
        }
        return "minigame_trainer";
    }

    /** Minigame page */
    @GetMapping("/game/zones")
    public String zonesGame(Model model, Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user != null) {
            model.addAttribute("progress", progressService.getOrCreate(user.getId()));
        }
        return "minigame";
    }

    /** Award XP after game session */
    @PostMapping("/game/xp")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> awardGameXp(
            @RequestParam int amount,
            @RequestParam(defaultValue = "minigame") String source,
            Principal principal, Authentication auth) {

        User user = currentUser(principal, auth);
        if (user == null) return ResponseEntity.status(401).build();

        // Cap per session to prevent abuse: max 300 XP
        int capped = Math.min(amount, 300);
        UserProgress p = progressService.addXp(user.getId(), capped, source);

        log.info("Minigame XP: user={} earned={} source={}", user.getId(), capped, source);

        return ResponseEntity.ok(Map.of(
                "xpEarned", capped,
                "totalXp",  p.getTotalXp(),
                "level",    p.getLevel()
        ));
    }
}
