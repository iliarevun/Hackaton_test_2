package com.example.shop.controller;

import com.example.shop.models.Challenge;
import com.example.shop.models.User;
import com.example.shop.repositories.UserRepository;
import com.example.shop.services.ChallengeService;
import com.example.shop.services.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
@Slf4j
public class ChallengeController {

    private final ChallengeService challengeService;
    private final UserService      userService;
    private final UserRepository   userRepository;

    // ── helpers ──────────────────────────────────────────────
    private User me(Principal p, Authentication auth) {
        if (auth instanceof OAuth2AuthenticationToken t)
            return userService.getUserByEmail(t.getPrincipal().getAttribute("email"));
        return p != null ? userService.getUserByPrincipal(p) : null;
    }

    private Map<String, Object> userInfo(Long userId) {
        return userRepository.findById(userId).map(u ->
            Map.<String, Object>of("id", u.getId(), "name", u.getName() != null ? u.getName() : "Герой",
                "avatar", u.getAvatar() != null ? "/avatars/" + u.getAvatar().getId() : "")
        ).orElse(Map.of("id", userId, "name", "Невідомий", "avatar", ""));
    }

    // ── PAGES ─────────────────────────────────────────────────

    /** GET /challenges — головна сторінка викликів */
    @GetMapping("/challenges")
    public String challengesPage(Model model, Principal p, Authentication auth) {
        User me = me(p, auth);
        if (me == null) return "redirect:/login";

        List<Challenge> all     = challengeService.allForUser(me.getId());
        List<Challenge> pending = challengeService.pendingForUser(me.getId());
        List<Challenge> active  = challengeService.activeForUser(me.getId());

        // Збагачуємо іменами
        all.forEach(c -> enrichChallenge(c, model));

        List<Map<String, Object>> allUsers = new java.util.ArrayList<>();
        for (User u : userRepository.findAll()) {
            if (u.getId().equals(me.getId())) continue;
            java.util.Map<String, Object> um = new HashMap<>();
            um.put("id",     u.getId());
            um.put("name",   u.getName() != null ? u.getName() : "Герой");
            um.put("avatar", u.getAvatar() != null ? "/avatars/" + u.getAvatar().getId() : "");
            allUsers.add(um);
        }

        model.addAttribute("me", me);
        model.addAttribute("allChallenges", all);
        model.addAttribute("pendingChallenges", pending);
        model.addAttribute("activeChallenges", active);
        model.addAttribute("allUsers", allUsers);
        model.addAttribute("pendingCount", pending.size());
        return "challenges";
    }

    private void enrichChallenge(Challenge c, Model model) {
        // Only for template: sender/receiver names are fetched via AJAX or REST
    }

    // ── REST API ──────────────────────────────────────────────

    /** POST /api/challenges/send */
    @PostMapping("/api/challenges/send")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> send(
            @RequestBody Map<String, Object> body,
            Principal p, Authentication auth) {

        User me = me(p, auth);
        if (me == null) return ResponseEntity.status(401).build();

        try {
            Long receiverId    = Long.valueOf(body.get("receiverId").toString());
            String exercise    = body.get("exerciseName").toString();
            String emoji       = body.getOrDefault("emoji", "🏋️").toString();
            int    target      = Integer.parseInt(body.get("targetCount").toString());
            String unit        = body.getOrDefault("unit", "повторень").toString();
            int    days        = Integer.parseInt(body.getOrDefault("deadlineDays", "7").toString());

            if (me.getId().equals(receiverId))
                return ResponseEntity.badRequest().body(Map.of("error", "Не можна кинути виклик самому собі"));

            Challenge c = challengeService.send(me.getId(), receiverId, exercise, emoji, target, unit, days);
            return ResponseEntity.ok(Map.of(
                "id", c.getId(), "status", c.getStatus(),
                "message", "Виклик надіслано!"
            ));
        } catch (Exception e) {
            log.error("Send challenge error: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** POST /api/challenges/{id}/accept */
    @PostMapping("/api/challenges/{id}/accept")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> accept(
            @PathVariable Long id, Principal p, Authentication auth) {
        User me = me(p, auth);
        if (me == null) return ResponseEntity.status(401).build();
        Challenge c = challengeService.accept(id, me.getId());
        return ResponseEntity.ok(Map.of("status", c.getStatus().toString()));
    }

    /** POST /api/challenges/{id}/decline */
    @PostMapping("/api/challenges/{id}/decline")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> decline(
            @PathVariable Long id, Principal p, Authentication auth) {
        User me = me(p, auth);
        if (me == null) return ResponseEntity.status(401).build();
        Challenge c = challengeService.decline(id, me.getId());
        return ResponseEntity.ok(Map.of("status", c.getStatus().toString()));
    }

    /** POST /api/challenges/{id}/progress?amount=5 */
    @PostMapping("/api/challenges/{id}/progress")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> progress(
            @PathVariable Long id,
            @RequestParam int amount,
            Principal p, Authentication auth) {
        User me = me(p, auth);
        if (me == null) return ResponseEntity.status(401).build();
        try {
            Challenge c = challengeService.addProgress(id, me.getId(), amount);
            boolean isSender = me.getId().equals(c.getSenderId());
            Map<String, Object> result = new HashMap<>();
            result.put("senderProgress",   c.getSenderProgress());
            result.put("receiverProgress", c.getReceiverProgress());
            result.put("senderPct",        c.getSenderPct());
            result.put("receiverPct",      c.getReceiverPct());
            result.put("status",           c.getStatus().toString());
            result.put("myProgress",       isSender ? c.getSenderProgress() : c.getReceiverProgress());
            result.put("myPct",            isSender ? c.getSenderPct() : c.getReceiverPct());
            if (c.getWinnerId() != null) {
                result.put("winnerId", c.getWinnerId());
                result.put("iWon", me.getId().equals(c.getWinnerId()));
            }
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** GET /api/challenges/{id}/status — polling для live оновлення */
    @GetMapping("/api/challenges/{id}/status")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> status(
            @PathVariable Long id, Principal p, Authentication auth) {
        User me = me(p, auth);
        if (me == null) return ResponseEntity.status(401).build();
        return challengeService.findById(id).map(c -> {
            Map<String, Object> res = new HashMap<>();
            res.put("senderProgress",   c.getSenderProgress());
            res.put("receiverProgress", c.getReceiverProgress());
            res.put("senderPct",        c.getSenderPct());
            res.put("receiverPct",      c.getReceiverPct());
            res.put("status",           c.getStatus().toString());
            res.put("senderInfo",       userInfo(c.getSenderId()));
            res.put("receiverInfo",     userInfo(c.getReceiverId()));
            res.put("myId",             me.getId());
            if (c.getWinnerId() != null) {
                res.put("winnerId", c.getWinnerId());
                res.put("iWon", me.getId().equals(c.getWinnerId()));
            }
            return ResponseEntity.ok(res);
        }).orElse(ResponseEntity.notFound().build());
    }
}
