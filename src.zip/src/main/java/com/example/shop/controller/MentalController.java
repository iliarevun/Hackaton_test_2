package com.example.shop.controller;

import com.example.shop.models.DailyMood;
import com.example.shop.models.MentalTestResult;
import com.example.shop.models.User;
import com.example.shop.models.UserProgress;
import com.example.shop.repositories.DailyMoodRepository;
import com.example.shop.repositories.MentalTestResultRepository;
import com.example.shop.services.UserProgressService;
import com.example.shop.services.UserService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

import java.security.Principal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
@Slf4j
public class MentalController {

    private final ObjectMapper objectMapper;
    private final MentalTestResultRepository testResultRepo;
    private final DailyMoodRepository moodRepo;
    private final UserProgressService progressService;
    private final UserService userService;
    private final RestTemplate restTemplate;

    private static final String API_KEY = "AIzaSyANyfAdFNRLzyvh6ARkpoyWrthsJaoMQW0";

    private User currentUser(Principal principal,
                             org.springframework.security.core.Authentication auth) {
        if (auth instanceof OAuth2AuthenticationToken t)
            return userService.getUserByEmail(t.getPrincipal().getAttribute("email"));
        if (principal != null)
            return userService.findUserByPrincipal(principal.getName());
        return null;
    }

    @GetMapping("/mental")
    public String mentalPage(Model model, Principal principal,
                             org.springframework.security.core.Authentication auth) {
        User user = currentUser(principal, auth);
        if (user != null) {
            UserProgress progress = progressService.getOrCreate(user.getId());
            List<MentalTestResult> results = testResultRepo
                    .findByUserIdOrderByTakenAtDesc(user.getId());
            List<DailyMood> weekMoods = moodRepo.findByUserIdAndDateBetweenOrderByDateAsc(
                    user.getId(), LocalDate.now().minusDays(6), LocalDate.now());
            model.addAttribute("progress", progress);
            model.addAttribute("testResults", results);
            model.addAttribute("weekMoods", weekMoods);
        }
        return "mental";
    }

    @PostMapping("/mental/analyze")
    @ResponseBody
    public Map<String, String> analyzeText(@RequestBody Map<String, String> body,
                                           Principal principal,
                                           org.springframework.security.core.Authentication auth) {
        String text = body.getOrDefault("text", "");
        try {
            String prompt = "Ти доброзичливий психолог. Проаналізуй тональність цього тексту та дай 2-3 короткі, прості, не медичні поради для покращення настрою. Пиши українською, тепло і підтримуючи.\nТекст: \"" + text + "\"\nФормат відповіді: просто поради, без діагнозу.";

            Map<String, Object> req = Map.of(
                    "contents", List.of(Map.of("parts", List.of(Map.of("text", prompt)))));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=" + API_KEY;
            ResponseEntity<String> resp = restTemplate.postForEntity(url, new HttpEntity<>(req, headers), String.class);
            JsonNode root = objectMapper.readTree(resp.getBody());
            String advice = root.path("candidates").get(0).path("content").path("parts").get(0).path("text").asText();

            User user = currentUser(principal, auth);
            if (user != null) progressService.addXp(user.getId(), 15, "mental_analysis");

            return Map.of("advice", advice);
        } catch (Exception e) {
            log.error("Mental AI error: {}", e.getMessage());
            String[] tips = {
                    "Спробуй коротку прогулянку на свіжому повітрі — це творить дива! 🌿",
                    "Зроби 5 глибоких вдихів: вдих 4 сек, затримка 4 сек, видих 6 сек. 💙",
                    "Напиши 3 речі, за які ти вдячний сьогодні. Це змінює фокус думок! ✨"
            };
            return Map.of("advice", tips[(int) (Math.random() * 3)]);
        }
    }

    @PostMapping("/mental/mood/save")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> saveMood(
            @RequestBody Map<String, Object> body,
            Principal principal,
            org.springframework.security.core.Authentication auth) {

        User user = currentUser(principal, auth);
        if (user == null) return ResponseEntity.status(401).build();

        LocalDate today = LocalDate.now();
        moodRepo.findByUserIdAndDate(user.getId(), today)
                .ifPresent(moodRepo::delete);

        DailyMood mood = new DailyMood();
        mood.setUserId(user.getId());
        mood.setEmoji((String) body.get("emoji"));
        mood.setLabel((String) body.get("label"));
        mood.setMoodScore(((Number) body.getOrDefault("score", 3)).intValue());
        mood.setDate(today);
        moodRepo.save(mood);

        return ResponseEntity.ok(Map.of("saved", true, "date", today.toString()));
    }

    @GetMapping("/mental/mood/week")
    @ResponseBody
    public List<Map<String, Object>> getWeekMoods(
            Principal principal,
            org.springframework.security.core.Authentication auth) {

        User user = currentUser(principal, auth);
        if (user == null) return List.of();

        List<DailyMood> moods = moodRepo.findByUserIdAndDateBetweenOrderByDateAsc(
                user.getId(), LocalDate.now().minusDays(6), LocalDate.now());

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd.MM");
        return moods.stream().map(m -> Map.<String, Object>of(
                "date", m.getDate().format(fmt),
                "emoji", m.getEmoji(),
                "label", m.getLabel(),
                "score", m.getMoodScore()
        )).collect(Collectors.toList());
    }

    @PostMapping("/mental/week-analysis")
    @ResponseBody
    public Map<String, String> weekAnalysis(
            Principal principal,
            org.springframework.security.core.Authentication auth) {

        User user = currentUser(principal, auth);
        if (user == null) return Map.of("analysis", "Увійди, щоб отримати аналіз.");

        List<DailyMood> moods = moodRepo.findByUserIdAndDateBetweenOrderByDateAsc(
                user.getId(), LocalDate.now().minusDays(6), LocalDate.now());

        if (moods.isEmpty()) {
            return Map.of("analysis", "Не вистачає даних. Відмічай свій настрій щодня протягом тижня! 📅");
        }

        UserProgress progress = progressService.getOrCreate(user.getId());
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd.MM");
        String moodSummary = moods.stream()
                .map(m -> m.getDate().format(fmt) + ": " + m.getEmoji() + " " + m.getLabel() + " (" + m.getMoodScore() + "/5)")
                .collect(Collectors.joining(", "));

        try {
            String prompt = "Ти доброзичливий психолог-аналітик. Проаналізуй настрій користувача за тиждень та дай 2-3 персоналізовані поради. Пиши українською, тепло і коротко (не більше 5 речень). Відзнач будь-які паттерни або тенденції.\nСтатистика: тренувань виконано " + progress.getWorkoutsDone() + ", серія днів: " + progress.getStreakDays() + ".\nНастрій за тиждень: " + moodSummary;

            Map<String, Object> req = Map.of(
                    "contents", List.of(Map.of("parts", List.of(Map.of("text", prompt)))));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=" + API_KEY;
            ResponseEntity<String> resp = restTemplate.postForEntity(url, new HttpEntity<>(req, headers), String.class);
            JsonNode root = objectMapper.readTree(resp.getBody());
            String analysis = root.path("candidates").get(0).path("content").path("parts").get(0).path("text").asText();

            progressService.addXp(user.getId(), 25, "mental_week_analysis");
            return Map.of("analysis", analysis);
        } catch (Exception e) {
            log.error("Week analysis AI error: {}", e.getMessage());
            return Map.of("analysis", "Тримай рівновагу! Регулярний відпочинок та тренування — найкращий рецепт гарного настрою. 💙");
        }
    }

    @PostMapping("/mental/test/save")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> saveTestResult(
            @RequestBody Map<String, Object> body,
            Principal principal,
            org.springframework.security.core.Authentication auth) {

        User user = currentUser(principal, auth);

        MentalTestResult result = new MentalTestResult();
        if (user != null) result.setUserId(user.getId());
        result.setTestType((String) body.get("testType"));
        result.setTestName((String) body.get("testName"));
        result.setScore(((Number) body.get("score")).intValue());
        result.setMaxScore(((Number) body.get("maxScore")).intValue());
        result.setResultLabel((String) body.get("resultLabel"));
        result.setAdvice((String) body.get("advice"));

        int xp = ((Number) body.getOrDefault("xp", 40)).intValue();
        result.setXpEarned(xp);
        testResultRepo.save(result);

        if (user != null) progressService.addXp(user.getId(), xp, "mental_test");

        UserProgress progress = user != null ? progressService.getOrCreate(user.getId()) : new UserProgress();
        return ResponseEntity.ok(Map.of(
                "xpEarned", xp,
                "totalXp", progress.getTotalXp(),
                "mentalXp", progress.getMentalXp(),
                "level", progress.getLevel()
        ));
    }

    @PostMapping("/mental/xp")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> addMentalXp(
            @RequestParam int amount,
            Principal principal,
            org.springframework.security.core.Authentication auth) {
        User user = currentUser(principal, auth);
        if (user == null) return ResponseEntity.status(401).build();
        UserProgress p = progressService.addXp(user.getId(), amount, "mental_quest");
        return ResponseEntity.ok(Map.of(
                "totalXp", p.getTotalXp(),
                "mentalXp", p.getMentalXp(),
                "level", p.getLevel()
        ));
    }

    /** Deep AI analysis of test results */
    @PostMapping("/mental/test/deep-analysis")
    @ResponseBody
    public Map<String, String> deepTestAnalysis(
            @RequestBody Map<String, Object> body,
            Principal principal,
            org.springframework.security.core.Authentication auth) {

        String testType  = (String) body.getOrDefault("testType", "");
        int score        = ((Number) body.getOrDefault("score", 0)).intValue();
        int maxScore     = ((Number) body.getOrDefault("maxScore", 1)).intValue();
        String label     = (String) body.getOrDefault("resultLabel", "");
        Object answersRaw = body.get("answers");

        // Build answers summary string
        String answersSummary = "";
        if (answersRaw instanceof java.util.List<?> list) {
            StringBuilder sb = new StringBuilder();
            for (Object item : list) {
                if (item instanceof java.util.Map<?,?> m) {
                    sb.append("• ").append(m.get("q")).append(" → ").append(m.get("lbl")).append("\n");
                }
            }
            answersSummary = sb.toString();
        }

        String testNames = java.util.Map.of(
            "anxiety", "тривожність (GAD-7)",
            "depression", "депресія (PHQ-9)",
            "sleep", "якість сну",
            "stress", "рівень стресу (PSS)",
            "personality", "тип особистості",
            "burnout", "вигорання",
            "sport", "підбір виду спорту",
            "confidence", "впевненість у собі"
        ).getOrDefault(testType, testType);

        try {
            String prompt = String.format("""
                Ти досвідчений психолог і коуч. Зроби детальний, персоналізований аналіз результатів психологічного тесту.
                Пиши українською мовою, тепло, підтримуюче та конкретно.

                Тест: %s
                Результат: %s (%d / %d балів, %.0f%%)

                Відповіді користувача:
                %s

                Надай глибокий аналіз у такому форматі:
                1. **Що це означає** — поясни результат простими словами (2-3 речення)
                2. **Що добре** — відзнач позитивні аспекти (1-2 пункти)
                3. **На що звернути увагу** — конкретні зони для покращення на основі відповідей (2-3 пункти)
                4. **Практичні кроки** — 3 конкретних дії які можна зробити вже сьогодні
                5. **Мотивація** — одне надихаюче речення

                Будь конкретним, уникай загальних фраз. Враховуй конкретні відповіді де є проблеми.
                """,
                testNames, label, score, maxScore,
                (double) score / maxScore * 100, answersSummary);

            Map<String, Object> req = Map.of(
                    "contents", List.of(Map.of("parts", List.of(Map.of("text", prompt)))));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=" + API_KEY;
            ResponseEntity<String> resp = restTemplate.postForEntity(url, new HttpEntity<>(req, headers), String.class);
            JsonNode root = objectMapper.readTree(resp.getBody());
            String analysis = root.path("candidates").get(0).path("content").path("parts").get(0).path("text").asText();

            User user = currentUser(principal, auth);
            if (user != null) progressService.addXp(user.getId(), 10, "mental_deep_analysis");

            return Map.of("analysis", analysis);
        } catch (Exception e) {
            log.error("Deep analysis error: {}", e.getMessage());
            return Map.of("analysis",
                "На основі твоїх відповідей:\n\n" +
                "✅ Ти зробив важливий крок — пройшов тест і аналізуєш своє здоров'я.\n\n" +
                "💡 Рекомендую:\n" +
                "• Запиши 3 речі які хочеш покращити\n" +
                "• Поговори з близькою людиною про свій стан\n" +
                "• Спробуй медитацію 5 хвилин сьогодні\n\n" +
                "🌟 Ти вже на правильному шляху, продовжуй! 💙");
        }
    }
}
