package com.example.shop.controller;

import com.example.shop.dto.LeaderboardEntryDTO;
import com.example.shop.dto.WorkoutDayDTO;
import com.example.shop.models.*;
import com.example.shop.repositories.UserBodyRepository;
import com.example.shop.repositories.UserProgressRepository;
import com.example.shop.services.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.Principal;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
@Slf4j
public class PhysicalController {

    private final UserBodyRepository userBodyRepository;
    private final UserProgressRepository userProgressRepository;
    private final WorkoutPlanService workoutPlanService;
    private final UserProgressService progressService;
    private final UserService userService;
    private final ObjectMapper objectMapper;

    private User currentUser(Principal principal, Authentication auth) {
        if (auth instanceof OAuth2AuthenticationToken t)
            return userService.getUserByEmail(t.getPrincipal().getAttribute("email"));
        if (principal != null)
            return userService.findUserByPrincipal(principal.getName());
        return null;
    }

    private List<WorkoutDayDTO> parseJson(String json) {
        if (json == null || json.isBlank() || json.equals("[]")) return Collections.emptyList();
        try {
            // Очищення пробілів та некоректних символів
            String clean = json.replaceAll("(?s)```json\\s*", "").replaceAll("(?s)```\\s*", "").trim();
            if (!clean.endsWith("]")) {
                clean = clean + "]";
            }
            return objectMapper.readValue(clean, new TypeReference<>() {});
        } catch (Exception e) {
            log.error("JSON parse error: {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    @GetMapping("/")
    public String main(@RequestParam(name = "title", required = false) String title,
                       Model model, Principal principal,
                       Authentication authentication,
                       HttpServletRequest httpServletRequest) throws IOException {

        User user = null;

        if (authentication instanceof OAuth2AuthenticationToken token) {
            userService.createUserFromOAuth2(model, token);
            String email = token.getPrincipal().getAttribute("email");
            user = userService.getUserByEmail(email);
        } else if (authentication instanceof UsernamePasswordAuthenticationToken) {
            user = userService.getUserByPrincipal(principal);
        }

        if (user != null) {
            user.setCoins(BigDecimal.valueOf(user.getCoins())
                    .setScale(1, RoundingMode.HALF_UP).doubleValue());
            model.addAttribute("user", user);

            // Pass progress so header XP pill and dropdown work
            UserProgress progress = progressService.getOrCreate(user.getId());
            model.addAttribute("progress", progress);
        }

        CsrfToken csrfToken = (CsrfToken) httpServletRequest.getAttribute("_csrf");
        model.addAttribute("csrfParameterName", csrfToken.getParameterName());
        model.addAttribute("csrfToken", csrfToken.getToken());

        return "main";
    }
    
    @GetMapping("/physical")
    public String toPhysical(Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user == null) return "redirect:/login";
        // Check if user already has BOTH body data AND a workout plan saved
        boolean hasBody = userBodyRepository.findFirstByUserIdOrderByIdDesc(user.getId()).isPresent();
        boolean hasPlan = workoutPlanService.getPlanEntity(user.getId()) != null;
        if (hasBody && hasPlan) {
            return "redirect:/plan";   // ← go straight to existing plan, NO re-generation
        }
        return "redirect:/setup";      // ← only go to setup if missing body or plan
    }

    @GetMapping("/setup")
    public String setupPage(Model model) {
        model.addAttribute("body", new UserBody());
        return "setup";
    }

    @PostMapping("/setup")
    public String saveBody(@ModelAttribute UserBody body, Model model, Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user != null) {
            body.setUserId(user.getId());
        }

        log.info("Setup POST: goal={}, equipment={}, location={}, days={}, dur={}, health={}, inj={}",
                body.getGoal(), body.getEquipment(), body.getWorkoutLocation(),
                body.getWorkoutDaysPerWeek(), body.getWorkoutDurationMinutes(),
                body.getHealthConditions(), body.getInjuries());

        // Зберігаємо профіль
        userBodyRepository.save(body);

        // Генеруємо план
        WorkoutPlan plan = workoutPlanService.createPlan(body);
        List<WorkoutDayDTO> days = parseJson(plan.getAiGeneratedPlan());

        log.info("Direct rendering for {} workout days", days.size());

        // Передаємо змінні напряму, без перенаправлення (redirect)
        model.addAttribute("days", days);
        model.addAttribute("body", body);
        model.addAttribute("plan", plan);

        // Add progress so plan.ftlh header XP pill works
        if (user != null) {
            UserProgress progress = progressService.getOrCreate(user.getId());
            model.addAttribute("progress", progress);
        } else {
            model.addAttribute("progress", new UserProgress());
        }

        return "plan";
    }

    @GetMapping("/plan")
    public String showPlan(Model model, Principal principal, Authentication auth) {
        try {
            User user = currentUser(principal, auth);
            if (user == null) return "redirect:/login";

            UserBody body = userBodyRepository.findFirstByUserIdOrderByIdDesc(user.getId()).orElseThrow();
            WorkoutPlan plan = workoutPlanService.getPlanEntity(body.getId()); // або body.getUserId() залежить від вашої реалізації
            if (plan == null) return "redirect:/setup";

            model.addAttribute("days", parseJson(plan.getAiGeneratedPlan()));
            model.addAttribute("plan", plan);
            model.addAttribute("body", body);
            UserProgress progress = progressService.getOrCreate(user.getId());
            model.addAttribute("progress", progress);
        } catch (Exception e) {
            return "redirect:/setup";
        }
        return "plan";
    }

    @GetMapping("/leaderboard")
    public String showLeaderboard(Model model) {
        List<UserProgress> topProgress = userProgressRepository.findAll().stream()
                .sorted(Comparator.comparing(UserProgress::getTotalXp).reversed())
                .limit(10)
                .collect(Collectors.toList());

        List<LeaderboardEntryDTO> entries = topProgress.stream()
                .map(p -> {
                    User u = userService.getUserById(p.getUserId());
                    String name = (u != null && u.getName() != null) ? u.getName() : "Герой";
                    Long avatarId = (u != null && u.getAvatar() != null) ? u.getAvatar().getId() : null;
                    return new LeaderboardEntryDTO(
                            p.getUserId(), name,
                            u != null ? u.getEmail() : "",
                            avatarId,
                            p.getTotalXp(), p.getLevel(),
                            p.getStreakDays(), p.getWorkoutsDone()
                    );
                })
                .collect(Collectors.toList());

        model.addAttribute("entries", entries);
        return "leaderboard";
    }

    @PostMapping("/physical/xp")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> addXp(
            @RequestParam int amount,
            @RequestParam(defaultValue = "physical") String source,
            Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user == null) return ResponseEntity.status(401).build();
        UserProgress p = progressService.addXp(user.getId(), amount, source);
        return ResponseEntity.ok(Map.of(
                "totalXp", p.getTotalXp(),
                "level", p.getLevel(),
                "levelPct", p.getLevelProgressPct()
        ));
    }

    @PostMapping("/physical/workout-done")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> workoutDone(Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user == null) return ResponseEntity.status(401).build();
        UserProgress p = progressService.workoutDone(user.getId());
        return ResponseEntity.ok(Map.of(
                "totalXp", p.getTotalXp(),
                "level", p.getLevel(),
                "streakDays", p.getStreakDays(),
                "workoutsDone", p.getWorkoutsDone()
        ));
    }

    @PostMapping("/physical/location")
    @ResponseBody
    public ResponseEntity<?> setLocation(@RequestParam String emoji, @RequestParam String name,
                                         Principal principal, Authentication auth) {
        User user = currentUser(principal, auth);
        if (user == null) return ResponseEntity.status(401).build();
        progressService.setLocation(user.getId(), emoji, name);
        return ResponseEntity.ok().build();
    }
}
