package com.example.shop.models;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

/**
 * Stores the user's daily mood selection from the Mental page.
 * One record per user per day (upsert logic in MentalController).
 */
@Entity
@Table(name = "daily_mood")
@Data
public class DailyMood {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    /** Emoji symbol: 😄 😊 😐 😔 😰 */
    @Column(name = "emoji")
    private String emoji;

    /** Human-readable label: Відмінно, Добре, Нейтрально, Погано, Тривожно */
    @Column(name = "label")
    private String label;

    /** Numeric score 1–5 (5 = best) */
    @Column(name = "mood_score")
    private int moodScore;

    @Column(name = "date")
    private LocalDate date;

    @PrePersist
    public void prePersist() {
        if (this.date == null) {
            this.date = LocalDate.now();
        }
    }
}
