package com.example.shop.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "WorkoutPlan")
@Data
public class WorkoutPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    @Column(columnDefinition = "TEXT")
    private String aiGeneratedPlan;

    // getters setters
}
