package com.example.shop.models;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Stores results of psychological tests per user.
 */
@Entity
@Table(name = "mental_test_result")
@Data
public class MentalTestResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "test_type")
    private String testType; // anxiety, depression, sleep, stress

    @Column(name = "test_name")
    private String testName;

    @Column(name = "score")
    private int score;

    @Column(name = "max_score")
    private int maxScore;

    @Column(name = "result_label")
    private String resultLabel; // e.g. "Низький рівень тривоги"

    @Column(name = "advice", length = 1000)
    private String advice;

    @Column(name = "xp_earned")
    private int xpEarned;

    @Column(name = "taken_at")
    private LocalDateTime takenAt;

    @PrePersist
    public void prePersist() {
        this.takenAt = LocalDateTime.now();
    }

    /** FreeMarker-friendly formatted date — use ${r.formattedDate} in templates */
    public String getFormattedDate() {
        if (takenAt == null) return "";
        return takenAt.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
    }
}
