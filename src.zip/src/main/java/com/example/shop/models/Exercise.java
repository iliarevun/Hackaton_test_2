package com.example.shop.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Exercise {

    @Id
    @GeneratedValue
    private Long id;

    private Long userId;

    private String day;

    private String name;

    private int sets;

    private int reps;

}
