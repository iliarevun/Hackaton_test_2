package com.example.shop.models;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "challenges")
@Data
public class Challenge {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sender_id", nullable = false)
    private Long senderId;

    @Column(name = "receiver_id", nullable = false)
    private Long receiverId;

    @Column(name = "exercise_name", nullable = false)
    private String exerciseName;       // "Присідання"

    @Column(name = "exercise_emoji")
    private String exerciseEmoji;      // "🏋️"

    @Column(name = "target_count", nullable = false)
    private int targetCount;           // 30

    @Column(name = "unit")
    private String unit = "повторень"; // повторень / хвилин / кроків

    @Column(name = "deadline_days")
    private int deadlineDays = 7;      // тиждень

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private ChallengeStatus status = ChallengeStatus.PENDING;

    @Column(name = "sender_progress")
    private int senderProgress = 0;

    @Column(name = "receiver_progress")
    private int receiverProgress = 0;

    @Column(name = "reward_xp")
    private int rewardXp = 200;

    @Column(name = "reward_badge")
    private String rewardBadge;        // "⚔️ Переможець дуелі"

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    @Column(name = "winner_id")
    private Long winnerId;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
        this.expiresAt = LocalDateTime.now().plusDays(this.deadlineDays);
    }

    public enum ChallengeStatus {
        PENDING,   // чекає на прийняття
        ACTIVE,    // активний
        COMPLETED, // завершений
        DECLINED,  // відхилений
        EXPIRED    // час вийшов
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }

    public int getSenderPct()   { return targetCount > 0 ? Math.min(100, senderProgress   * 100 / targetCount) : 0; }
    public int getReceiverPct() { return targetCount > 0 ? Math.min(100, receiverProgress * 100 / targetCount) : 0; }
    public boolean senderWinning()   { return senderProgress > receiverProgress; }
    public boolean receiverWinning() { return receiverProgress > senderProgress; }
}
