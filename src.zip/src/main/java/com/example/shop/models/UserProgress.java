package com.example.shop.models;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * Stores XP, level, streak and gamification data per user.
 * One row per user (userId is unique).
 */
@Entity
@Table(name = "user_progress")
@Data
public class UserProgress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", unique = true)
    private Long userId;

    @Column(name = "total_xp")
    private int totalXp = 0;

    @Column(name = "level")
    private int level = 1;

    @Column(name = "physical_xp")
    private int physicalXp = 0;

    @Column(name = "mental_xp")
    private int mentalXp = 0;

    @Column(name = "streak_days")
    private int streakDays = 0;

    @Column(name = "workouts_done")
    private int workoutsDone = 0;

    @Column(name = "exercises_done")
    private int exercisesDone = 0;

    @Column(name = "quests_done")
    private int questsDone = 0;

    @Column(name = "last_workout_date")
    private LocalDateTime lastWorkoutDate;

    @Column(name = "active_location")
    private String activeLocation = "Міський парк";

    @Column(name = "active_location_emoji")
    private String activeLocationEmoji = "🌲";

    /** XP needed to reach next level (100 * level) */
    public int getXpForNextLevel() {
        return level * 100;
    }

    /** Progress % toward next level */
    public int getLevelProgressPct() {
        int xpInLevel = totalXp - xpForLevel(level);
        int xpNeeded = getXpForNextLevel();
        if (xpNeeded <= 0) return 100;
        return Math.min(100, (int) ((xpInLevel * 100.0) / xpNeeded));
    }

    private int xpForLevel(int lvl) {
        // Sum of all previous level thresholds: 100+200+...+(lvl-1)*100
        return (lvl - 1) * lvl / 2 * 100;
    }

    public void addXp(int amount) {
        this.totalXp += amount;
        // Auto level-up
        while (this.totalXp >= xpForLevel(this.level + 1)) {
            this.level++;
        }
    }
}
