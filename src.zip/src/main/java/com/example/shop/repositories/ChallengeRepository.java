package com.example.shop.repositories;

import com.example.shop.models.Challenge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ChallengeRepository extends JpaRepository<Challenge, Long> {

    @Query("SELECT c FROM Challenge c WHERE c.senderId = :uid OR c.receiverId = :uid ORDER BY c.createdAt DESC")
    List<Challenge> findAllByUserId(@Param("uid") Long userId);

    @Query("SELECT c FROM Challenge c WHERE c.receiverId = :uid AND c.status = 'PENDING'")
    List<Challenge> findPendingForUser(@Param("uid") Long userId);

    @Query("SELECT c FROM Challenge c WHERE (c.senderId = :uid OR c.receiverId = :uid) AND c.status = 'ACTIVE'")
    List<Challenge> findActiveByUserId(@Param("uid") Long userId);
}
