package com.example.shop.repositories;

import com.example.shop.models.WorkoutPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WorkoutPlanRepository extends JpaRepository<WorkoutPlan, Long> {
    WorkoutPlan findFirstByUserIdOrderByIdDesc(Long userId);
    Optional<WorkoutPlan> findTopByUserIdOrderByIdDesc(Long userId);

    List<WorkoutPlan> findByUserId(Long userId);
}
