package com.example.shop.repositories;

import com.example.shop.models.MentalTestResult;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MentalTestResultRepository extends JpaRepository<MentalTestResult, Long> {
    List<MentalTestResult> findByUserIdOrderByTakenAtDesc(Long userId);
    List<MentalTestResult> findByUserIdAndTestTypeOrderByTakenAtDesc(Long userId, String testType);
}
