package com.example.shop.repositories;

import com.example.shop.models.DailyMood;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface DailyMoodRepository extends JpaRepository<DailyMood, Long> {

    /** All moods for a user in a date range (inclusive), ordered by date. */
    List<DailyMood> findByUserIdAndDateBetweenOrderByDateAsc(Long userId, LocalDate from, LocalDate to);

    /** Today's mood for upsert logic. */
    Optional<DailyMood> findByUserIdAndDate(Long userId, LocalDate date);
}
