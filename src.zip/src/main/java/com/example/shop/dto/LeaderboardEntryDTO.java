package com.example.shop.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LeaderboardEntryDTO {
    private Long userId;
    private String name;
    private String email;
    private Long avatarId;
    private int totalXp;
    private int level;
    private int streakDays;
    private int workoutsDone;
}
