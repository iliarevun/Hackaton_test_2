package com.example.shop.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkoutDayDTO {
    private String day;
    private List<ExerciseDTO> exercises;

    public WorkoutDayDTO() {}

    public String getDay() { return day; }
    public void setDay(String day) { this.day = day; }
    public List<ExerciseDTO> getExercises() { return exercises; }
    public void setExercises(List<ExerciseDTO> exercises) { this.exercises = exercises; }

    public boolean isRestDay() {
        return exercises == null || exercises.isEmpty();
    }
}
