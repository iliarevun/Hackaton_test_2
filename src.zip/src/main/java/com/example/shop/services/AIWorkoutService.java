package com.example.shop.services;

import com.example.shop.dto.WorkoutDayDTO;
import com.example.shop.models.UserBody;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class AIWorkoutService {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    private static final String API_KEY = "AIzaSyCd1swjms3HhteTmESxrMYpLvipKfZpN4c";

    public List<WorkoutDayDTO> generatePlan(UserBody body) throws Exception {

        String equipmentStr = (body.getEquipment() != null && !body.getEquipment().isBlank())
                ? body.getEquipment() : "тільки власна вага тіла (без обладнання)";

        String locationStr = switch (body.getWorkoutLocation() != null ? body.getWorkoutLocation() : "HOME") {
            case "GYM"     -> "в тренажерному залі";
            case "OUTDOOR" -> "на вулиці / на майданчику";
            default        -> "вдома";
        };

        int days = body.getWorkoutDaysPerWeek() > 0 ? body.getWorkoutDaysPerWeek() : 3;
        int duration = body.getWorkoutDurationMinutes() > 0 ? body.getWorkoutDurationMinutes() : 45;

        String healthStr = buildHealthSection(body);

        String prompt = """
            Ти персональний тренер. Створи тижневий план тренувань для користувача.
            
            ПРОФІЛЬ КОРИСТУВАЧА:
            - Вік: %d років
            - Зріст: %d см, Вага: %d кг
            - Стать: %s
            - Ціль: %s
            - Рівень підготовки: %s
            - Місце тренувань: %s
            - Наявне обладнання: %s
            - Тренувань на тиждень: %d
            - Тривалість тренування: %d хвилин
            %s
            
            ВИМОГИ:
            1. Використовуй ТІЛЬКИ зазначене обладнання. Не призначай вправи з відсутнім обладнанням.
            2. Враховуй обмеження здоров'я — уникай вправ, що можуть нашкодити.
            3. Кількість тренувальних днів = %d, решта — дні відпочинку.
            4. Кожне тренування має тривати ~%d хвилин. Максимальна кількість вправ на день: не більше 5.
            5. Повертай ТІЛЬКИ JSON масив. Без markdown, без пояснень.
            
            ФОРМАТ (суворо дотримуйся):
            [{"day":"Понеділок","exercises":[{"name":"Назва вправи","sets":3,"reps":"12"}]},{"day":"Вівторок","exercises":[]},...]
            
            Включи всі 7 днів. Дні відпочинку мають порожній масив exercises.
            """.formatted(
                body.getAge(), body.getHeight(), body.getWeight(),
                body.getGender() != null ? body.getGender() : "не вказано",
                body.getGoalLabel(), body.getActivityLevel(),
                locationStr, equipmentStr, days, duration,
                healthStr, days, duration
        );

        Map<String, Object> requestBody = Map.of(
                "contents", List.of(Map.of("parts", List.of(Map.of("text", prompt)))),
                "generationConfig", Map.of(
                        "temperature", 0.4,
                        "maxOutputTokens", 4000
                )
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY;

        log.info("Calling Gemini API: goal={}, equipment={}, days={}", body.getGoal(), equipmentStr, days);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);

        JsonNode root = objectMapper.readTree(response.getBody());

        if (root.has("error")) {
            throw new RuntimeException("Gemini error: " + root.get("error").get("message").asText());
        }

        String text = root.path("candidates").get(0)
                .path("content").path("parts").get(0)
                .path("text").asText();

        // Захист від обрізання
        int start = text.indexOf('[');
        int end   = text.lastIndexOf(']');
        if (start != -1 && end > start) {
            text = text.substring(start, end + 1);
        } else {
            text = text.replaceAll("(?s)```json\\s*", "").replaceAll("(?s)```\\s*", "").trim();
            if (!text.endsWith("]")) text = text + "]"; // Додаємо відсутню дужку
        }

        log.info("AI response (first 200): {}", text.substring(0, Math.min(200, text.length())));
        return objectMapper.readValue(text, new TypeReference<>() {});
    }

    private String buildHealthSection(UserBody body) {
        StringBuilder sb = new StringBuilder();
        boolean hasHealth = body.getHealthConditions() != null && !body.getHealthConditions().isBlank();
        boolean hasInjuries = body.getInjuries() != null && !body.getInjuries().isBlank();
        boolean hasNotes = body.getHealthNotes() != null && !body.getHealthNotes().isBlank();

        if (hasHealth || hasInjuries || hasNotes) {
            sb.append("\nОБМЕЖЕННЯ ЗДОРОВ'Я:");
            if (hasHealth)   sb.append("\n  - Стан здоров'я: ").append(body.getHealthConditions());
            if (hasInjuries) sb.append("\n  - Травми/болі: ").append(body.getInjuries());
            if (hasNotes)    sb.append("\n  - Додатково: ").append(body.getHealthNotes());
        }
        return sb.toString();
    }
}