package com.example.shop.services;

import com.example.shop.models.Challenge;
import com.example.shop.models.Challenge.ChallengeStatus;
import com.example.shop.repositories.ChallengeRepository;
import com.example.shop.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChallengeService {

    private final ChallengeRepository repo;
    private final UserProgressService  progressService;
    private final UserRepository       userRepository;

    /** Надіслати виклик */
    public Challenge send(Long senderId, Long receiverId, String exerciseName,
                          String emoji, int targetCount, String unit, int deadlineDays) {
        Challenge c = new Challenge();
        c.setSenderId(senderId);
        c.setReceiverId(receiverId);
        c.setExerciseName(exerciseName);
        c.setExerciseEmoji(emoji != null ? emoji : "🏋️");
        c.setTargetCount(targetCount);
        c.setUnit(unit != null ? unit : "повторень");
        c.setDeadlineDays(deadlineDays > 0 ? deadlineDays : 7);
        c.setRewardXp(calculateXp(targetCount));
        c.setRewardBadge("⚔️ Переможець дуелі");
        c.setStatus(ChallengeStatus.PENDING);
        return repo.save(c);
    }

    /** Прийняти виклик */
    public Challenge accept(Long challengeId, Long userId) {
        return repo.findById(challengeId).map(c -> {
            if (!c.getReceiverId().equals(userId)) return c;
            if (c.getStatus() != ChallengeStatus.PENDING) return c;
            c.setStatus(ChallengeStatus.ACTIVE);
            return repo.save(c);
        }).orElseThrow();
    }

    /** Відхилити */
    public Challenge decline(Long challengeId, Long userId) {
        return repo.findById(challengeId).map(c -> {
            if (!c.getReceiverId().equals(userId)) return c;
            c.setStatus(ChallengeStatus.DECLINED);
            return repo.save(c);
        }).orElseThrow();
    }

    /** Додати прогрес */
    public Challenge addProgress(Long challengeId, Long userId, int amount) {
        return repo.findById(challengeId).map(c -> {
            if (c.getStatus() != ChallengeStatus.ACTIVE) return c;
            if (c.isExpired()) { c.setStatus(ChallengeStatus.EXPIRED); return repo.save(c); }

            if (c.getSenderId().equals(userId)) {
                c.setSenderProgress(Math.min(c.getSenderProgress() + amount, c.getTargetCount() + 9999));
            } else if (c.getReceiverId().equals(userId)) {
                c.setReceiverProgress(Math.min(c.getReceiverProgress() + amount, c.getTargetCount() + 9999));
            }

            // Перевірити чи хтось досяг цілі
            boolean senderDone   = c.getSenderProgress()   >= c.getTargetCount();
            boolean receiverDone = c.getReceiverProgress() >= c.getTargetCount();

            if (senderDone || receiverDone) {
                finishChallenge(c, senderDone, receiverDone);
            }
            return repo.save(c);
        }).orElseThrow();
    }

    private void finishChallenge(Challenge c, boolean senderDone, boolean receiverDone) {
        c.setStatus(ChallengeStatus.COMPLETED);
        Long winnerId;
        if (senderDone && receiverDone) {
            // Обидва — перемагає хто більше виконав
            winnerId = c.getSenderProgress() >= c.getReceiverProgress()
                       ? c.getSenderId() : c.getReceiverId();
        } else {
            winnerId = senderDone ? c.getSenderId() : c.getReceiverId();
        }
        c.setWinnerId(winnerId);

        // XP переможцю
        progressService.addXp(winnerId, c.getRewardXp(), "challenge_win");
        // Втішний приз переможеному
        Long loserId = winnerId.equals(c.getSenderId()) ? c.getReceiverId() : c.getSenderId();
        progressService.addXp(loserId, 50, "challenge_participate");

        log.info("Challenge {} completed. Winner: {}", c.getId(), winnerId);
    }

    public List<Challenge> allForUser(Long userId)     { return repo.findAllByUserId(userId); }
    public List<Challenge> pendingForUser(Long userId) { return repo.findPendingForUser(userId); }
    public List<Challenge> activeForUser(Long userId)  { return repo.findActiveByUserId(userId); }
    public Optional<Challenge> findById(Long id)       { return repo.findById(id); }

    private int calculateXp(int target) {
        if (target <= 20)  return 100;
        if (target <= 50)  return 200;
        if (target <= 100) return 350;
        return 500;
    }
}
