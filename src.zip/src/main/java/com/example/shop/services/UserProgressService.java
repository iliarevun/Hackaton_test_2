package com.example.shop.services;

import com.example.shop.models.UserProgress;
import com.example.shop.repositories.UserProgressRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserProgressService {

    private final UserProgressRepository repo;

    /** Get or create progress for a user */
    public UserProgress getOrCreate(Long userId) {
        return repo.findByUserId(userId).orElseGet(() -> {
            UserProgress p = new UserProgress();
            p.setUserId(userId);
            return repo.save(p);
        });
    }

    /** Add XP and save */
    public UserProgress addXp(Long userId, int amount, String source) {
        UserProgress p = getOrCreate(userId);
        int oldLevel = p.getLevel();
        p.addXp(amount);
        if (source != null && source.startsWith("physical")) {
            p.setPhysicalXp(p.getPhysicalXp() + amount);
        } else if (source != null && source.startsWith("mental")) {
            p.setMentalXp(p.getMentalXp() + amount);
        }
        UserProgress saved = repo.save(p);
        if (saved.getLevel() > oldLevel) {
            log.info("User {} leveled up to {}", userId, saved.getLevel());
        }
        return saved;
    }

    /** Mark a workout day done */
    public UserProgress workoutDone(Long userId) {
        UserProgress p = getOrCreate(userId);
        p.setWorkoutsDone(p.getWorkoutsDone() + 1);
        p.setStreakDays(p.getStreakDays() + 1);
        p.setLastWorkoutDate(java.time.LocalDateTime.now());
        p.addXp(80);
        p.setPhysicalXp(p.getPhysicalXp() + 80);
        return repo.save(p);
    }

    /** Mark an exercise done (+10 XP) */
    public UserProgress exerciseDone(Long userId) {
        UserProgress p = getOrCreate(userId);
        p.setExercisesDone(p.getExercisesDone() + 1);
        p.addXp(10);
        p.setPhysicalXp(p.getPhysicalXp() + 10);
        return repo.save(p);
    }

    /** Mark a quest done */
    public UserProgress questDone(Long userId, int xp) {
        UserProgress p = getOrCreate(userId);
        p.setQuestsDone(p.getQuestsDone() + 1);
        p.addXp(xp);
        return repo.save(p);
    }

    public UserProgress setLocation(Long userId, String emoji, String name) {
        UserProgress p = getOrCreate(userId);
        p.setActiveLocation(name);
        p.setActiveLocationEmoji(emoji);
        return repo.save(p);
    }

    public UserProgress save(UserProgress p) {
        return repo.save(p);
    }
}
