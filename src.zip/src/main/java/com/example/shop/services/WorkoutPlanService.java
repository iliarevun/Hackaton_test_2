package com.example.shop.services;

import com.example.shop.dto.WorkoutDayDTO;
import com.example.shop.models.UserBody;
import com.example.shop.models.WorkoutPlan;
import com.example.shop.repositories.WorkoutPlanRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.client.HttpClientErrorException;

import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class WorkoutPlanService {

    private final AIWorkoutService aiWorkoutService;
    private final WorkoutPlanRepository workoutPlanRepository;
    private final ObjectMapper objectMapper;

    @Retryable(
            value = { HttpServerErrorException.ServiceUnavailable.class, HttpClientErrorException.TooManyRequests.class },
            maxAttempts = 3,
            backoff = @Backoff(delay = 5000) // Затримка 5 секунд перед повтором
    )
    public WorkoutPlan createPlan(UserBody body) {
        try {
            log.info("Generating AI plan for userId={}, goal={}", body.getUserId(), body.getGoal());
            List<WorkoutDayDTO> planDto = aiWorkoutService.generatePlan(body);

            if (planDto == null || planDto.isEmpty()) {
                log.warn("Generated plan is empty. Fallback used.");
                planDto = Collections.emptyList();
            }

            String json = objectMapper.writeValueAsString(planDto);
            log.info("AI returned {} days, JSON length={}", planDto.size(), json.length());

            // Видалення старих планів для уникнення помилки NonUniqueResultException
            List<WorkoutPlan> oldPlans = workoutPlanRepository.findByUserId(body.getUserId());
            if (oldPlans != null && !oldPlans.isEmpty()) {
                workoutPlanRepository.deleteAll(oldPlans);
            }

            WorkoutPlan entity = new WorkoutPlan();
            entity.setUserId(body.getUserId());
            entity.setAiGeneratedPlan(json);
            return workoutPlanRepository.save(entity);
        } catch (Exception e) {
            log.error("Plan generation failed: {}", e.getMessage());
            WorkoutPlan fallback = new WorkoutPlan();
            fallback.setUserId(body.getUserId());
            fallback.setAiGeneratedPlan("[]");
            return workoutPlanRepository.save(fallback);
        }
    }

    public WorkoutPlan getPlanEntity(Long userId) {
        return workoutPlanRepository.findFirstByUserIdOrderByIdDesc(userId);
    }

    public List<WorkoutDayDTO> getLatestPlan(Long userId) throws Exception {
        WorkoutPlan entity = workoutPlanRepository.findFirstByUserIdOrderByIdDesc(userId);
        if (entity == null || entity.getAiGeneratedPlan() == null) return null;

        return objectMapper.readValue(entity.getAiGeneratedPlan(), new TypeReference<List<WorkoutDayDTO>>() {});
    }
}